package dev.blog.common;

/**
 * 권한 타입
 */
public enum Role {
    USER, ADMIN
}
